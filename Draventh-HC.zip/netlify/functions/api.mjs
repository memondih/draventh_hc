import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

export const config = { path: "/api/*" };

const DEFAULT = {
  name: "DraventhHardcore ⚔", tagline: "Server hardcore roleplay: mati berarti terlempar ke kehampaan.", ip: "isi.ip.server",
  about: "DraventhHardcore adalah server bertema hardcore yang mengharuskan pemainnya bertahan hidup. Jika mati, pemain akan terlempar ke dalam kehampaan dan bangkit dalam 6 menit.\n\nPemain dapat melakukan apa saja selagi mematuhi batasan. Monopoli, manipulasi, omong kosong, dan kebohongan boleh dilakukan selama masuk ke dalam roleplay yang sedang berjalan. Semua di server ini berjalan tanpa script.",
  rules: [
    "No rusuh.", "No bunuh tanpa RP.", "Wajib menggunakan voice chat.", "No porno.", "No pedo.", "No judge OOC.",
    "No X-ray.", "No cheat.", "No client cheat.", "No dupe.",
    "Dilarang menyimpan Ancient Debris dan Netherite Scrap ke dalam furnace. Pelanggaran dikenai peringatan, banned, atau kill character.",
    "Dilarang memakai texture atau mod yang membantu survival, contoh: Glow Ore texture, Xaero's Map, dan sejenisnya."
  ],
  features: [
    { title: "Random Teleport", text: "" }, { title: "Disable Chat", text: "" }, { title: "Voice Chat", text: "" },
    { title: "DeathDimension", text: "Pemain yang mati dilempar ke kehampaan dan bangkit dalam 6 menit." },
    { title: "Trading Player", text: "" },
    { title: "Head Sit", text: "Kirim request untuk duduk di kepala pemain lain." },
    { title: "VeinMiner", text: "" },
    { title: "Treecapitator", text: "Pohon langsung hancur sekaligus." }
  ],
  players: [],
  note: "Saya selaku owner DraventhHC berterima kasih kepada kalian yang telah membaca aturan. Saya harap kalian semua mematuhinya, dan jika ada yang tidak mematuhinya, tolong laporkan.",
  posts: [{ id: "1", title: "Selamat datang di DraventhHC", date: new Date().toISOString().slice(0, 10), body: "Postingan pertama. Edit atau hapus lewat admin panel." }]
};

const json = (d, s = 200) => new Response(JSON.stringify(d), { status: s, headers: { "content-type": "application/json", "cache-control": "no-store" } });
const secret = () => process.env.TOKEN_SECRET || process.env.ADMIN_PASS || "x";
const sign = (p) => crypto.createHmac("sha256", secret()).update(p).digest("base64url");
const same = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
const valid = (t) => {
  const [p, s] = String(t || "").split(".");
  if (!p || !s || !same(s, sign(p))) return false;
  return Number(p) > Date.now();
};

export default async (req) => {
  const path = new URL(req.url).pathname;
  const store = getStore("site");

  if (path === "/api/content" && req.method === "GET") {
    return json((await store.get("content", { type: "json" })) || DEFAULT);
  }
  if (path === "/api/login" && req.method === "POST") {
    const { username, password } = await req.json().catch(() => ({}));
    const ok = process.env.ADMIN_USER && process.env.ADMIN_PASS &&
      same(username ?? "", process.env.ADMIN_USER) && same(password ?? "", process.env.ADMIN_PASS);
    if (!ok) { await new Promise((r) => setTimeout(r, 1000)); return json({ error: "Username atau password salah." }, 401); }
    const p = String(Date.now() + 1000 * 60 * 60 * 8);
    return json({ token: `${p}.${sign(p)}` });
  }
  if (path === "/api/content" && req.method === "PUT") {
    if (!valid((req.headers.get("authorization") || "").replace("Bearer ", ""))) return json({ error: "Sesi habis, login lagi." }, 401);
    const d = await req.json().catch(() => null);
    if (!d || typeof d !== "object") return json({ error: "Data tidak valid." }, 400);
    await store.setJSON("content", d);
    return json({ ok: true });
  }
  return json({ error: "Not found" }, 404);
};
